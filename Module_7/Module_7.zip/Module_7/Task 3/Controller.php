<?php
include '../sharedViewTop.php';

echo "Demo on phpmyadmin <br> <a href='http://localhost:8080/'>Some shady link</a> ";

include '../sharedViewBottom.php';
