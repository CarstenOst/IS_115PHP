<?php

namespace Repositories;

class ErrorCode
{
    /**
     * Negative value to not interfere with ID's
     */
    const DUPLICATE_EMAIL = -23000;

}
