<?php
namespace Database;

class DBConfig
{
    // I like const better than define, because it is more visible in the IDE
    const DB_HOST_NAME = '127.0.0.1';
    const DB_NAME = 'mod7';
    const DB_USER_NAME = 'root';
    const DB_PASSWORD = '123';

}
