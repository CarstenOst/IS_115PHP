<?php
// Without a for loop*******
include 'Counter.php';
include '../sharedViewTop.php';

Counter::count(9);