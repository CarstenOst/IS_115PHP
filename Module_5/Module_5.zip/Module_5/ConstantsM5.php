<?php

const ENCRYPTING = 'Encrypt';
const DECRYPTING = 'Decrypt';

const CELSIUS = 'Celsius';
const FAHRENHEIT = 'Fahrenheit';


const INPUT_FIELDS_M5T4 = [
    ENCRYPTING => 'Enter your string to encrypt',
    DECRYPTING => 'Enter your encrypted string to decrypt'
];

const INPUT_FIELDS_M5T5 = [
    CELSIUS => 'Enter degrees in celsius',
    FAHRENHEIT => 'Enter degrees in fahrenheit'
];
