<?php
const NAME = 'Name';
const EMAIL_RECIPIENT = 'Email';
const NUMBER_COOKIE = 'Number';

const SUBJECT = 'Subject';
const MESSAGE = 'Message';

const INPUT_FIELDS = [
    NAME => 'Enter your name*',
    EMAIL_RECIPIENT => 'Enter your email*',
    NUMBER_COOKIE => 'Enter your number*'
];

const INPUT_FIELDS_TASK_1 = [
    NAME => 'Enter your name*',
    EMAIL_RECIPIENT => 'Enter your recipients email*',
    SUBJECT => 'Enter your subject',
    MESSAGE => 'Enter your message'
];
