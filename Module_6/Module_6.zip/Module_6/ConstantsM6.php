<?php

const EMAIL = 'Email';
const PHONE = 'Phone';
const PASSWORD = 'Password';

const VALIDATION_INPUT_FIELDS = [
    EMAIL => 'Enter your email',
    PHONE => 'Enter your number',
    PASSWORD => 'Enter your password'
];

