<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="../styles.css">
    <title>Module 2</title>
</head>
<body>
<div class="center">
    <nav id="navbar" style="align-items: center" >
        <?php require_once 'sharedFunctions.php';sharedFunctions::generateNavigationButtons('Module_2');?>
    </nav>
    <div id="content" class="center" style="padding-top: 55px;">
