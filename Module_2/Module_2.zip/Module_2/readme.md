How to input html or php code in task 1;
Write any letter before the html or php code. Otherwise, removeNonLetterPrefix() will remove the code.
```
SometextBeforeHtmlOrPhpCode <h1>hello</h1>
```

The same goes for task 2, but here the code will be removed anyway.
The other tasks do not need clarifications.
