<?php

namespace Repositories;

class ErrorCode
{
    const DUPLICATE_EMAIL = 23000;

}
