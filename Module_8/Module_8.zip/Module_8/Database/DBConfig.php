<?php

namespace Database;
class DBConfig
{
    const DB_HOST_NAME = '127.0.0.1';
    const DB_NAME = 'mod8';
    const DB_USER_NAME = 'root';
    const DB_PASSWORD = '123';

}
