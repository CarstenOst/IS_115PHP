<?php

namespace Enums;

enum UserTypes: string{
    case Student = 'student';
    case Tutor = 'tutor';
}