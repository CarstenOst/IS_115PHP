<?php
const NAME_COOKIE = 'Name';
const EMAIL_COOKIE = 'Email';
const NUMBER_COOKIE = 'Number';

const SUBJECT = 'Subject';
const MESSAGE = 'Message';

const INPUT_FIELDS = [
    NAME_COOKIE => 'Enter your name*',
    EMAIL_COOKIE => 'Enter your email*',
    NUMBER_COOKIE => 'Enter your number*'
];

const INPUT_FIELDS_TASK_5 = [
    NAME_COOKIE => 'Enter your name*',
    EMAIL_COOKIE => 'Enter your email*',
    SUBJECT => 'Enter your subject',
    MESSAGE => 'Enter your message'
];
