<?php
$navn = "Buschocracy";
$hilsen = "Hilsen Carsten";
?>
<p> God morgen <?php echo $navn?>! </p>
<p> <?php echo $hilsen?>. </p>