<!DOCTYPE html>
<meta http-equiv="refresh" content="0; 4_Kalkulator.php" />
<!-- Now this is funny? -->